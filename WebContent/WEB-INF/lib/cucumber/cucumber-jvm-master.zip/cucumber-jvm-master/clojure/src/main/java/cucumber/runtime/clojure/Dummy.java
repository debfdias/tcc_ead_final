package cucumber.runtime.clojure;

// Nothing to see here, just a workaround for https://github.com/cucumber/cucumber-jvm/issues/270
public class Dummy {
}
