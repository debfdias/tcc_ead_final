package cucumber.runtime.jruby;

public class World {
}
