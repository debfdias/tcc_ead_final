package cucumber.runtime.table;

public interface StringConverter {
    String map(String string);
}
