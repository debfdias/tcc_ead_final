package cucumber.runtime.java.stepdefs;

import cucumber.api.java.en.Given;

public class Stepdefs {

    @Given("test")
    public void test() {

    }
}
