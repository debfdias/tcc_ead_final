package cucumber.runtime.java.test;

import cucumber.api.java.en.Given;

public class Stepdefs {
    @Given("^I have (\\d+) cukes in the belly$")
    public void I_have_cukes_in_the_belly(int arg1) {
    }
}
