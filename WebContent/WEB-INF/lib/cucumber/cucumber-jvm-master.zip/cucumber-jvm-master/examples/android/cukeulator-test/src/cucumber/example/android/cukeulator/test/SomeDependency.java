package cucumber.example.android.cukeulator.test;

// Dummy class to demonstrate dependency injection
public class SomeDependency {
}
