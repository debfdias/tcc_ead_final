package cucumber.example.android.test;

// Dummy class to demonstrate dependency injection
public class SomeDependency {
}
