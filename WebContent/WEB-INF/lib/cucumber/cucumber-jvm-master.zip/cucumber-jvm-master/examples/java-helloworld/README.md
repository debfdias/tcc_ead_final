## This example has moved

Please [go here](https://github.com/cucumber/cucumber-java-skeleton).
