This is a TestNG copy-paste version of the [JUnit Calculator example](https://github.com/cucumber/cucumber-jvm/tree/master/examples/java-calculator) project.

If you find its TestNG report is not idiomatic, consider making a contribution to improve Cucumber JVM TestNG Support.  

**Note**
Please keep code base of this project up-to-date

