## Groovy Example

copied from cuke4duke groovy example


## Running Example

mvn test
