package cucumber.runtime.java.guice.integration;

public class UnScopedObject {
}
